package cornez.com.finalproject;

import android.media.Image;

import java.util.Map;

/**
 * Created by Paul Regan on 12/7/2016.
 */
public class Profile {
    public String username;
    public String password;
    public int image;



    public Profile(String userName, String passWord, int pic){
        username=userName;
        password=passWord;
        image = pic;


    }

}
