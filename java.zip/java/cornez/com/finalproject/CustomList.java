package cornez.com.finalproject;

/**
 * Created by Paul Regan on 12/13/2016.
 */
import android.app.Activity;
import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;

import java.util.List;

public class CustomList extends ArrayAdapter<String>{

    private final Activity context;
    private final List<String> web;
    private final List<Integer>imageId;
    private final List<String> loc;
    private final List<String> Time;


    public CustomList(Activity context,
                      List<String> webs, List<Integer> imageId, List<String> Location, List<String> time) {
        super(context, R.layout.listview, webs);
        this.context = context;
        this.web = webs;
        this.imageId = imageId;
        this.loc = Location;
        this.Time=time;

    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.listview, null, true);
        TextView txtTitle = (TextView) rowView.findViewById(R.id.txt);
        TextView txtLocation = (TextView) rowView.findViewById(R.id.editText3);
        TextView txtTime = (TextView) rowView.findViewById(R.id.editText4);

        ImageView imageView = (ImageView) rowView.findViewById(R.id.img);
        txtTitle.setText( web.get(position));
        txtLocation.setText(loc.get(position));
        txtTime.setText(Time.get(position));


        imageView.setImageResource(imageId.get(position));

        return rowView;
    }
}
