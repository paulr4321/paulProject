package cornez.com.finalproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Paul Regan on 12/14/2016.
 */
public class SignUp extends MainActivity{

    TextView username;
    TextView pass;
    TextView privacy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        username = (EditText)findViewById(R.id.editText);
        pass = (EditText)findViewById(R.id.editText2);
        privacy = (EditText)findViewById(R.id.editText6);

    }



    public void onClick(View view){
        userImage = (R.drawable.propic);
    }
    public void onClick2(View view){
        userImage=(R.drawable.propic2);
    }
    public void onClick3(View view){
        userName = String.valueOf(username.getText());
        userPassWord = String.valueOf(pass.getText());
        newUser = new Profile (userName,userPassWord,userImage);
        editor = getSharedPreferences(userName, MODE_PRIVATE).edit();
        editor.putString("username",String.valueOf(userName));
        editor.apply();
        editor = getSharedPreferences(userPassWord, MODE_PRIVATE).edit();
        editor.putString("password",String.valueOf(pass));
        editor.apply();
        editor = getSharedPreferences(String.valueOf(userImage), MODE_PRIVATE).edit();
        editor.putString("image",String.valueOf(userImage));
        editor.apply();
        editor = getSharedPreferences(String.valueOf(privacy), MODE_PRIVATE).edit();
        editor.putString("image",String.valueOf(privacy));
        editor.apply();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
