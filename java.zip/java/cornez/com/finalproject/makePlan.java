//package cornez.com.finalproject;
//
///**
// * Created by Paul Regan on 12/7/2016.
// */
//public class makePlan {
//    //class that implements and saves info for posts
//    //Where?
//    //When?
//    //With?
//}
