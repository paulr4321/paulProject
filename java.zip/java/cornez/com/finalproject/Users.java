package cornez.com.finalproject;

import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Users {
    List<Profile> profiles = new ArrayList<Profile>();
    List<String> passwords = new ArrayList<String>();
    List<Integer> propic = new ArrayList<Integer>();
    List<String> userNames= new ArrayList<String>();
    List<String> locations= new ArrayList<String>();
    List<String> time= new ArrayList<String>();
    List<String> friends= new ArrayList<String>();



    public Users (){

    }
    public void addUser(Profile pro ){
        profiles.add(pro);
    }
    public void addPass(String pass){
        passwords.add(pass);
    }
    public void addPic(int pic){
        propic.add(pic);
    }
    public void addUserName(String username){
        userNames.add(username);
    }
    public void addlocation(String location){
        locations.add(location);
    }
    public void time (String Time){
        time.add(Time);
    }



}