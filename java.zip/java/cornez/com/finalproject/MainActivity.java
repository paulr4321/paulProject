package cornez.com.finalproject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Paul Regan on 12/14/2016.
 */
public class MainActivity extends Activity {
    public static final String PREFS_NAME = "MyPrefsFile";

    public static Users users;
    public static String userName;
    public static String userPassWord;
    public static int userImage;
    public static Profile newUser;
    public TextView loggedOn;
    public ImageView proPic;
    public CustomList adapter;
    SharedPreferences settings;

    SharedPreferences.Editor editor = settings.edit();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loggedOn=(TextView)findViewById(R.id.textView);
        proPic = (ImageView)findViewById(R.id.imageView);
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.apply();
        editor.putString("username",userName);
        editor.putInt("image", userImage);
        editor.putString("password", userPassWord);

        proPic.setImageResource(userImage);
        loggedOn.setText(userName);


    }
    public void onClick(View view){
        Intent intent = new Intent(this, checkIn.class);
        startActivity(intent);
    }
    public void onClick2(View view){
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }
    public void onClick3(View view){
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    @Override
    public void onResume(){
        super.onResume();
        userName = settings.getString("username",null);
        userPassWord = settings.getString("username",null);
        userImage = settings.getInt("username",-1);
        proPic.setImageResource(userImage);
        loggedOn.setText(userName);


    }
}
