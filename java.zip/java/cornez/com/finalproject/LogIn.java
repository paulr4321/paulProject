//package cornez.com.finalproject;
//
///**
// * Created by Paul Regan on 12/7/2016.
// */
//public class LogIn {
//    //Two edit text boxs. After slecting a button to submit user password and username
//    //The values in the edit text box are checked with the data base of users with a node or something
//    //which keys with their password and allows entry if accepted
//    //If there is no username or password or if the password does not correlate with a username
//    //Toast- deliver a message saying that username or password was incorrect
//    //Also, if username and password found in database, An intent would be called and
//    //send to a home page with a feed filtered for that specific users friends list (prob hard to make a unique home page)
//}
