package cornez.com.finalproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by Paul Regan on 12/14/2016.
 */
public class main extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.home);
    }
    public void onClick(View view){
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }
}