//package cornez.com.finalproject;
//
//import java.util.List;
//
///**
// * Created by Paul Regan on 12/13/2016.
// */
//public class checkInData {
//    List<String> Location;
//    List<String> Time;
//    public checkInData(String location, String time){
//
//
//
//    }
//    public void addLoc()
//}
