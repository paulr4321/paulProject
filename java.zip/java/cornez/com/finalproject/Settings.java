package cornez.com.finalproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Paul Regan on 12/14/2016.
 */
public class Settings extends MainActivity{

    TextView userN;
    TextView passW;
    TextView priv;




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        userN = (EditText)findViewById(R.id.editText);
        passW = (EditText)findViewById(R.id.editText2);
        priv = (EditText)findViewById(R.id.editText6);




    }
    public void onClick(View view){
        userImage = (R.drawable.propic);
    }
    public void onClick2(View view){
        userImage=(R.drawable.propic2);
    }
    public void onClick3(View view){
        editor = getSharedPreferences(userName, MODE_PRIVATE).edit();
        editor.putString("username",String.valueOf(userN));
        editor.apply();
        editor = getSharedPreferences(userPassWord, MODE_PRIVATE).edit();
        editor.putString("password",String.valueOf(passW));
        editor.apply();
        editor = getSharedPreferences(String.valueOf(userImage), MODE_PRIVATE).edit();
        editor.putString("image",String.valueOf(userImage));
        editor.apply();
        editor = getSharedPreferences(String.valueOf(priv), MODE_PRIVATE).edit();
        editor.putString("image",String.valueOf(priv));
        editor.apply();
        onBackPressed();
    }
}