package cornez.com.finalproject;

/**
 * Created by Paul Regan on 12/7/2016.
 */
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class checkIn extends MainActivity {
    TextView Location;
    TextView Time;
    TextView What;
    String what;
     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.checkin_frag);
         Location = (EditText)findViewById(R.id.editText);
         Time = (EditText)findViewById(R.id.editText5);

         }



    public void onClick(View view){
        users.addlocation(String.valueOf(Location.getText()));
        users.time(String.valueOf(Time.getText()));
        users.addUserName(MainActivity.newUser.username);
        users.addPic(MainActivity.newUser.image);


        adapter=new CustomList(this,users.userNames, users.propic,users.locations,users.time);
        onBackPressed();
    }


}
